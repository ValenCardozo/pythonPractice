# Ejercicio 1
# Pedir dos números enteros, sumarlos y mostrar el resultado.

firstNumber = int(input('Ingrese el primer numero: '))
secondNumber = int(input('Ingrese el segundo numero: '))

response = firstNumber + secondNumber

print('La suma de', firstNumber, 'y', secondNumber, 'es', response)

# Ejercicio 3
# Leer un número real y emitir una leyenda informando
# si es mayor o igual a cero o bien es negativo (son dos opciones).

number = int(input('Ingrese un numero: '))

if number >= 0:
    print('Es mayor o igual a cero')
else:
    print('Es menor a cero')

# Ejercicio 7
# Mostrar los primeros 12 múltiplos de 5

count = 1
while count <= 12:
    pot = 5 ** count
    print(f'La potencia {count} de 5 es {pot}')
    count = count + 1
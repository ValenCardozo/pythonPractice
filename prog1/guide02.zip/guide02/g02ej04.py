# Ejercicio 4
# Mostrar por pantalla todos los números enteros negativos de una sola cifra.

start = -10
for i in range(9):
    print(start + i + 1)
